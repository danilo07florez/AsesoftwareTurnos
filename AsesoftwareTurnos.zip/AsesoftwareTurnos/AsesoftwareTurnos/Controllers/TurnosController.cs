﻿using Business.Interfaces;
using Core.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AsesoftwareTurnos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TurnosController : ControllerBase
    {
        private readonly IAswServices _aswService;

        public TurnosController(IAswServices aswService)
        {
            _aswService = aswService;
        }


        [HttpGet]
        public async Task<ActionResult> Get()
        {
            try
            {
                //var listTarjetas = await _dbContext.TarjetaCredito.ToListAsync();
                var listTurnos = _aswService.ConsultarTurnos();
                return Ok(listTurnos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("{idServicio}")]
        public async Task<ActionResult> Get(long idServicio)
        {
            try
            {
                var listTurnos = _aswService.ConsultarTurnosId(idServicio);
                return Ok(listTurnos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpPost]
        public ActionResult Post([FromBody] TurnoCrearView value)
        {
            try
            {
                var listaTurnos = new List<TurnoView>();
                string turnos = _aswService.CrearTurnos(value, out listaTurnos);

                if(!string.IsNullOrEmpty(turnos))
                    return Ok(turnos);
                else
                    return Ok(listaTurnos);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
