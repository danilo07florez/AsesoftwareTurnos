﻿using Business.Interfaces;
using Core.Models;
using Infrastructure.DBContext;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Implementations
{
    public class AswServices : IAswServices
    {
        private readonly AplicationsDBContext _dbcontext;

        public AswServices(AplicationsDBContext dbcontext)
        {
            _dbcontext = dbcontext;
        }


        public List<ServicioView> ConsultarServicios()
        {
            List<ServicioView> listaservicioViews = new List<ServicioView>();
            var listServicios = _dbcontext.Servicios.ToList();

            if (listServicios != null)
            {
                foreach (var item in listServicios)
                {
                    ServicioView servicioView = new ServicioView()
                    {

                        id_servicio = item.id_servicio,
                        id_comercio = item.id_comercio,
                        nom_servicio = item.nom_servicio,
                        hora_apertura = item.hora_apertura.ToShortTimeString(),
                        hora_cierre = item.hora_cierre.ToShortTimeString(),
                        duracion = item.duracion

                    };
                    listaservicioViews.Add(servicioView);
                }
            }

            return listaservicioViews;
        }

        public List<TurnoView> ConsultarTurnos()
        {
            List<TurnoView> listaturnosViews = new List<TurnoView>();
            var listTurnos = _dbcontext.Turnos.ToList();

            if (listTurnos != null)
            {
                foreach (var item in listTurnos)
                {
                    TurnoView servicioView = new TurnoView()
                    {

                        id_servicio = item.id_servicio,
                        id_turno = item.id_turno,
                        fecha_turno = item.fecha_turno.ToShortDateString(),
                        //hora_inicio =  item.hora_inicio.ToString(@"hh\:mm"),
                        hora_inicio = (DateTime.Today.Add(item.hora_inicio)).ToString("hh:mm tt"),
                        hora_fin = (DateTime.Today.Add(item.hora_fin)).ToString("hh:mm tt"),
                        estado = !item.estado ? "libre" : "ocupado"

                    };
                    listaturnosViews.Add(servicioView);
                }
            }

            return listaturnosViews;
        }




        public string CrearTurnos (TurnoCrearView member, out List<TurnoView> listaTurnos)
        {
            string mensaje = "";
            listaTurnos = new List<TurnoView>();

            try
            {
                mensaje = ValidacionesTurnos(member);


                if (string.IsNullOrEmpty(mensaje))
                {

                    string fechaInicio = member.fecha_incio.ToString("yyyy/MM/dd");
                    string fechaFin = member.fecha_fin.ToString("yyyy/MM/dd");


                    SqlConnection conexion = (SqlConnection)_dbcontext.Database.GetDbConnection();
                    SqlCommand sqlCommand = conexion.CreateCommand();
                    conexion.Open();
                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlCommand.CommandText = "GenerarTurnosDiarios";
                    sqlCommand.Parameters.Add("@FechaInicio", System.Data.SqlDbType.Date).Value = fechaInicio;
                    sqlCommand.Parameters.Add("@FechaFin", System.Data.SqlDbType.Date).Value = fechaFin;
                    sqlCommand.Parameters.Add("@IdServicio", System.Data.SqlDbType.Int).Value = member.id_servicio;
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        long id = (long)reader["id_turno"];
                        TurnoView servicioView = new TurnoView()
                        {

                            id_servicio = (long)reader["id_servicio"],
                            id_turno = (long)reader["id_turno"],
                            fecha_turno = ((DateTime)reader["fecha_turno"]).ToShortDateString(),
                            hora_inicio = (DateTime.Today.Add((TimeSpan)reader["hora_inicio"])).ToString("hh:mm tt"),
                            hora_fin = (DateTime.Today.Add((TimeSpan)reader["hora_fin"])).ToString("hh:mm tt"),
                            estado = "libre"

                        };
                        listaTurnos.Add(servicioView);
                    }
                    conexion.Close();
                }
                else
                {
                    return mensaje;
                }
            }
            catch (Exception ex)
            {
                mensaje = ex.Message;
            }

           return mensaje;
        }

        private string ValidacionesTurnos(TurnoCrearView member)
        {
            string mensaje = "";
            DateTime fechaActual = DateTime.Now;
            string cultureString = "es-CO";


            if (fechaActual.Year != member.fecha_incio.Year)
            {
                mensaje = "error en la fecha inicio!";
            }
            else if (fechaActual.Year != member.fecha_fin.Year)
            {
                mensaje = "error en la fecha fin!";
            }
            else if (member.fecha_incio > member.fecha_fin)
            {
                mensaje = "la fecha inicio no puede ser mayor a la fecha fin!";
                return mensaje;
            }


            var validarServicio = _dbcontext.Servicios.Where(x => x.id_servicio == member.id_servicio).FirstOrDefault();
            if (validarServicio == null)
            {
                mensaje = "Id Servicio digitado no existe!";
                return mensaje;
            }
            else
            {
                var validarTurno = _dbcontext.Turnos.Where(x => x.id_servicio == member.id_servicio).ToList();
                if (validarTurno != null)
                {
                    string fechaI = member.fecha_incio.ToShortDateString();
                    string fechaF = member.fecha_fin.ToShortDateString();

                    foreach (var item in validarTurno)
                    {
                        string turno = item.fecha_turno.ToShortDateString();

                        if (item.fecha_turno.ToShortDateString() == member.fecha_incio.ToShortDateString() || item.fecha_turno.ToShortDateString() == member.fecha_fin.ToShortDateString())
                        {
                            mensaje = "la siguiente fecha " + item.fecha_turno + " ya tiene turnos asignados";
                            break;
                        }

                    }
                    return mensaje;
                }

            }

            //bool fechaValida = DateTime.TryParse(date1, cultureString, styles, out fechaActual)


            string fechaInicio = member.fecha_incio.ToString("yyyy/MM/dd");
            string fechaFin = member.fecha_fin.ToString("yyyy/MM/dd");

            return mensaje;
        }

        private DateTime? FormatearFecha(string fecha)
        {
            try
            {
                DateTime dt = new DateTime();
                if (fecha == "Invalid Date")
                {
                    return null;
                }
                if (string.IsNullOrEmpty(fecha) || fecha == "null" || fecha == "undefined")
                {
                    return null;
                }
                else
                {
                    fecha = fecha.Contains("GMT") ? fecha.Substring(0, fecha.IndexOf("GMT")) : fecha;


                    if (DateTime.TryParseExact(fecha, "dd-mm-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                    {
                        //        
                        var fechaDate = Convert.ToDateTime(DateTime.ParseExact(fecha, "dd-MM-yyyy", CultureInfo.InvariantCulture));
                        dt = Convert.ToDateTime(fechaDate);
                    }

                    if (DateTime.TryParse(fecha, out dt))
                    {
                        dt = Convert.ToDateTime(fecha, CultureInfo.GetCultureInfo("es-CO").DateTimeFormat);
                    }
                    else if (!DateTime.TryParseExact(fecha, "mm-dd-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dt))
                    {
                        dt = Convert.ToDateTime(fecha, CultureInfo.GetCultureInfo("en-Us").DateTimeFormat);
                    }
                    else
                    {

                        dt = Convert.ToDateTime(fecha);
                    }

                    return dt;
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public List<TurnoView> ConsultarTurnosId(long id)
        {
            List<TurnoView> listaturnosViews = new List<TurnoView>();
            var listTurnos = _dbcontext.Turnos.Where(x => x.id_servicio == id).ToList();

            if (listTurnos != null)
            {
                foreach (var item in listTurnos)
                {
                    TurnoView servicioView = new TurnoView()
                    {

                        id_servicio = item.id_servicio,
                        id_turno = item.id_turno,
                        fecha_turno = item.fecha_turno.ToShortDateString(),
                        //hora_inicio =  item.hora_inicio.ToString(@"hh\:mm"),
                        hora_inicio = (DateTime.Today.Add(item.hora_inicio)).ToString("hh:mm tt"),
                        hora_fin = (DateTime.Today.Add(item.hora_fin)).ToString("hh:mm tt"),
                        estado = !item.estado ? "libre" : "ocupado"

                    };
                    listaturnosViews.Add(servicioView);
                }
            }

            return listaturnosViews;
        }

    }
}
