﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.EFModels
{
    public class Turnos
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long id_turno { get; set; }
        public long id_servicio { get; set; }
        public DateTime fecha_turno { get; set; }

        public TimeSpan hora_inicio { get; set; }
        public TimeSpan hora_fin { get; set; }
        public bool estado { get; set; }
    }
}
