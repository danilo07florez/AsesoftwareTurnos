﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    public class ServicioView
    {
        public long id_servicio { get; set; }
        public long id_comercio { get; set; }
        public string nom_servicio { get; set; }
        public string hora_apertura { get; set; }
        public string hora_cierre { get; set; }
        public int duracion { get; set; }
    }
}
