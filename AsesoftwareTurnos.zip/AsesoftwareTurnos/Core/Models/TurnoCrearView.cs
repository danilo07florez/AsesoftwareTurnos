﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    public class TurnoCrearView
    {
        [Display(Name = "Fecha Inicio")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime fecha_incio { get; set; }


        [Display(Name = "Fecha Fin")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime fecha_fin { get; set; } 


        //DateTime fecha = DateTime.Now;
        //// Formatear la fecha en 'dd/mm/yyyy'
        //string fechaFormateada = fecha.ToString("dd/MM/yyyy");

        [Display(Name = "Id Servicio")]
        public long id_servicio { get; set; }



    }
}
