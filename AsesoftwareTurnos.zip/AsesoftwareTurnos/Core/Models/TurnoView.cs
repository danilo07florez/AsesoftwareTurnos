﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    public class TurnoView
    {
        public long id_turno { get; set; }
        public long id_servicio { get; set; }
        public string fecha_turno { get; set; }
        public string hora_inicio { get; set; }
        public string hora_fin { get; set; }
        public string estado { get; set; }
    }
}
