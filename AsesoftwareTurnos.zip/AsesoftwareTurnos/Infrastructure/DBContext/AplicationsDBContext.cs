﻿using Core.EFModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DBContext
{
    public class AplicationsDBContext : DbContext
    {
        public DbSet<Servicio> Servicios { get; set; }
        public DbSet<Comercio> Comercios { get; set; }
        public DbSet<Turnos> Turnos { get; set; }
        public AplicationsDBContext(DbContextOptions<AplicationsDBContext> options) : base(options)
        {

        }

    }
}
