﻿using Infrastructure.DBContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestingTurnos
{
    public class BasePruebas
    {
        protected AplicationsDBContext ConstruirContext(string nombreDB)
        {
            var opciones = new DbContextOptionsBuilder<AplicationsDBContext>()
                .UseInMemoryDatabase(nombreDB).Options;

            var dbContext = new AplicationsDBContext(opciones);
            return dbContext;
        }
    }
}
