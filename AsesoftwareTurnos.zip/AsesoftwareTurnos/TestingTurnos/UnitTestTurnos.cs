using AsesoftwareTurnos.Controllers;
using Business.Implementations;
using Business.Interfaces;
using Core.Models;
using Infrastructure.DBContext;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;

namespace TestingTurnos
{
    public class UnitTestTurnos : BasePruebas
    {
        private readonly TurnosController _turnosController;
        private readonly ServicioController _servicioController;
        private readonly IAswServices _iaswService;
        private readonly AplicationsDBContext _dbcontext;
        private readonly AswServices _aswService;

        public UnitTestTurnos()
        {

            var services = new ServiceCollection();
            //services.AddTransient<IAswServices, AswServices>();
            var serviceProvider = services.BuildServiceProvider();


            ////
            _iaswService = new AswServices(_dbcontext);
            _turnosController = new TurnosController(_iaswService);
            _servicioController = new ServicioController(_iaswService);
 
        }

        [Fact]
        public void Get_servicio_OK()
        {
            var nombreBD = Guid.NewGuid().ToString();
            var contexto = ConstruirContext(nombreBD);
            contexto.Servicios.ToListAsync();


            //
            var contexto2 = ConstruirContext(nombreBD);
            var controller = new AswServices(contexto2);

            var result = controller.ConsultarServicios();
            //Assert.IsType<OkObjectResult>(result);
            Assert.Equal(2,result.Count);
        }

        [Fact]
        public void Create_turno_OK()
        {
            TurnoCrearView value = new TurnoCrearView();
            value.id_servicio = 6;
            value.fecha_incio = System.DateTime.Now;
            value.fecha_fin = System.DateTime.Now;

            var result = (OkObjectResult)_turnosController.Post(value);
            var listaTurnos = Assert.IsType<List<TurnoView>>(result.Value);
            Assert.True(listaTurnos.Count > 0);

        }


    }
}